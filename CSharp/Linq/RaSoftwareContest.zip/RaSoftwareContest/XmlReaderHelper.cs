﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace RaSoftwareContest
{
    public static class XmlReaderHelper
    {
        public static List<SeniorSchool> ReadSeniorSchools()
        {
            var list = new List<SeniorSchool>();
            var reader = new XmlTextReader("SeniorSchools.xml");
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element:
                        {
                            if (reader.Name.Equals("SeniorSchool"))
                            {
                                var item = new SeniorSchool
                                {
                                    ID = reader.GetAttribute("ID"),
                                    UnifiedEnrollNum = int.Parse(reader.GetAttribute("UnifiedEnrollNum")),
                                    TargetEnrollNum = int.Parse(reader.GetAttribute("TargetEnrollNum"))
                                };
                                list.Add(item);
                            }
                            break;
                        }
                }
            }
            return list;
        }

        public static List<JuniorSchool> ReadJuniorSchools()
        {
            var list = new List<JuniorSchool>();
            var reader = new XmlTextReader("JuniorSchools.xml");
            var temp = new JuniorSchool();
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element:
                        {
                            switch (reader.Name)
                            {
                                case "JuniorSchool":
                                    {
                                        temp = new JuniorSchool()
                                        {
                                            ID = reader.GetAttribute("ID")
                                        };
                                        list.Add(temp);
                                        break;
                                    }
                                case "TargetSeniorSchool":
                                    {
                                        var targetSchool = new TargetSeniorSchool
                                        {
                                            ID = reader.GetAttribute("ID"),
                                            EnrollNum = int.Parse(reader.GetAttribute("EnrollNum"))
                                        };
                                        temp.TargetSeniorSchools.Add(targetSchool.ID, targetSchool);
                                        break;
                                    }
                            }
                            break;
                        }
                }
            }
            return list;
        }

        public static List<Student> ReadStudents()
        {
            var list = new List<Student>();
            var reader = new XmlTextReader("Students.xml");
            var temp = new Student();
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element:
                        {
                            switch (reader.Name)
                            {
                                case "Student":
                                    {
                                        //var ID = reader.GetAttribute("ID");
                                        //var JuniorID = reader.GetAttribute("JuniorID");
                                        //var IsTarget = bool.Parse(reader.GetAttribute("IsTarget"));
                                        //var TargetSeniorSchool_ = reader.GetAttribute("TargetSeniorSchool");
                                        //var CanAdjust = bool.Parse(reader.GetAttribute("CanAdjust"));
                                        //var ChineseScore = int.Parse("ChineseScore");
                                        //var MathScore = int.Parse("MathScore");
                                        //var EnglishScore = int.Parse("EnglishScore");
                                        //var OtherScore = int.Parse("OtherScore");

                                        temp = new Student()
                                        {
                                            ID = reader.GetAttribute("ID"),
                                            JuniorID = reader.GetAttribute("JuniorID"),
                                            IsTarget = bool.Parse(reader.GetAttribute("IsTarget")),
                                            TargetSeniorSchool_ = reader.GetAttribute("TargetSeniorSchool"),
                                            CanAdjust = bool.Parse(reader.GetAttribute("CanAdjust")),
                                            ChineseScore = int.Parse(reader.GetAttribute("ChineseScore")),
                                            MathScore = int.Parse(reader.GetAttribute("MathScore")),
                                            EnglishScore = int.Parse(reader.GetAttribute("EnglishScore")),
                                            OtherScore = int.Parse(reader.GetAttribute("OtherScore"))
                                        };
                                        list.Add(temp);
                                        break;
                                    }
                                case "KeySeniorSchools":
                                    {
                                        temp.KeySeniorSchool_ = new KeySeniorSchool
                                        {
                                            FirstChoiceID = reader.GetAttribute("FirstChoiceID"),
                                            SecondChoiceID = reader.GetAttribute("SecondChoiceID"),
                                            ThirdChoiceID = reader.GetAttribute("ThirdChoiceID")
                                        };
                                        break;
                                    }
                                case "AdjustedTargetSchools":
                                    {
                                        temp.AdjustedTargetSchool_ = new AdjustedTargetSchool
                                        {
                                            FirstChoiceID = reader.GetAttribute("FirstChoiceID"),
                                            SecondChoiceID = reader.GetAttribute("SecondChoiceID")
                                        };
                                        break;
                                    }
                            }
                            break;
                        }
                }
            }
            return list;
        }
    }
}
