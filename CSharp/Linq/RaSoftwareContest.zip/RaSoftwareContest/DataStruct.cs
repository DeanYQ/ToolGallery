﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaSoftwareContest
{
    public class SeniorSchool
    {
        public string ID;

        public int UnifiedEnrollNum;

        public int TargetEnrollNum;
    }

    public class JuniorSchool
    {
        public JuniorSchool()
        {
            TargetSeniorSchools = new Dictionary<string, TargetSeniorSchool>();
        }

        public string ID;

        public Dictionary<string, TargetSeniorSchool> TargetSeniorSchools;
    }

    public class TargetSeniorSchool
    {
        public string ID;

        public int EnrollNum;
    }

    public class Student
    {
        public string ID;

        public string JuniorID;

        public bool IsTarget;

        public string TargetSeniorSchool_;

        public bool CanAdjust;

        public int ChineseScore;

        public int MathScore;

        public int EnglishScore;

        public int OtherScore;

        public KeySeniorSchool KeySeniorSchool_;

        public AdjustedTargetSchool AdjustedTargetSchool_;
    }

    public class KeySeniorSchool
    {
        public string FirstChoiceID;

        public string SecondChoiceID;

        public string ThirdChoiceID;
    }

    public class AdjustedTargetSchool
    {
        public string FirstChoiceID;

        public string SecondChoiceID;
    }

}
