﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaSoftwareContest
{
    class Program
    {
        static void Main(string[] args)
        {
            Test();
            Console.Read();
        }

        static void Test()
        {
            var seniorSchools = XmlReaderHelper.ReadSeniorSchools();
            var juniorSchools = XmlReaderHelper.ReadJuniorSchools();
            var students = XmlReaderHelper.ReadStudents();
        }
    }
}
