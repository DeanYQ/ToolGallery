﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    public class XmlDataManager
    {
        public int index = 0;

        private List<Task> tasks;

        public XmlDataManager()
        {
            tasks = new List<Task>();
            List = new List<List<XmlItem>>();
            List.Add(new List<XmlItem>());
        }

        public List<List<XmlItem>> List;

        public void Add(XmlItem item)
        {
            if (index == 1000000)
            {
                index = 0;
                int cur = List.Count;
                var task = Task.Run(() =>
                {
                    List[cur - 1].Sort(Comparison);
                });
                tasks.Add(task);

                List.Add(new List<XmlItem>());
            }
            List[List.Count - 1].Add(item);
            index++;
        }

        private int Comparison(XmlItem x, XmlItem y)
        {
            return x.Value - y.Value;
        }

        public XmlItem[] Complete()
        {
            if (Task.WaitAll(tasks.ToArray(), int.MaxValue))
            {
                return Merge();
            }
            return null;
        }

        public XmlItem[] Merge()
        {
            int length = 0;
            for (var i = 0; i < List.Count; i++)
            {
                length += List[i].Count;
            }

            var tagArray = new int[List.Count];
            var array = new XmlItem[length];

            //for (var i = 0; i < List.Count; i++)
            //{
            //    tagArray[i] = List[i].Count;
            //}

            for (var i = 0; i < length; i++)
            {
                array[i] = MinItem(tagArray);
            }
            return array;
        }

        public XmlItem MinItem(int[] tags)
        {
            XmlItem min = new XmlItem();
            var tag = 0;
            for (int i = 0; i < List.Count; i++)
            {
                if (tags[i] == 1000000 || tags[i] == List[i].Count)
                    continue;

                if (min.Id == null)
                {
                    tag = i;
                    min = List[i][tags[i]];
                    continue;
                }

                if (List[i][tags[i]].Value < min.Value)
                {
                    tag = i;
                    min = List[i][tags[i]];
                }
            }
            tags[tag]++;
            return min;
        }
    }
}
