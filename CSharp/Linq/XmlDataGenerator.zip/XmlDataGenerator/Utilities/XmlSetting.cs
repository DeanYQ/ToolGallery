﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    public class XmlSetting
    {
        public int ItemCount { get; set; }

        public int MaxAttrCount { get; set; }

        public int MaxAttrValue { get; set; }

        public int ChildCount { get; set; }
    }
}
