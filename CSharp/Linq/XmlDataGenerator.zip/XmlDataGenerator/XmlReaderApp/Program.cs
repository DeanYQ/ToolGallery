﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Utilities;
using System.IO;

namespace XmlReaderApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Generate();
            SetTestFunc();
            //Test1();
            //Test2();
            //Console.WriteLine(int.MaxValue);
            Test3();
            Console.Read();
        }

        static void SetTestFunc()
        {
            //Generate();
            SetTest.ArrayTest();
            //HashSetTest();
            SetTest.DictionaryTest();
            SetTest.ListTest();
        }

        static void Test1()
        {
            var watcher1 = new Stopwatch();
            var setting = LoadSetting();
            var helper = new XmlHelper(setting);
            watcher1.Start();

            var array = helper.ReadToArray();
            //Console.WriteLine("Array: Read: {0}", watcher1.ElapsedMilliseconds);

            XmlItem[] copy3 = (XmlItem[])array.Clone();
            SortHelper.QuickSort(copy3, 0, array.Length - 1);
            Console.WriteLine("Array: QuickSort2: {0}", watcher1.ElapsedMilliseconds);

            WriteCsv(copy3);
            watcher1.Stop();
        }

        static void Test2()
        {
            var watcher1 = new Stopwatch();
            var setting = LoadSetting();
            var helper = new XmlHelper(setting);
            watcher1.Start();

            var array = helper.ReadToArray2();
            Console.WriteLine("Array: QuickSort2: {0}", watcher1.ElapsedMilliseconds);

            WriteCsv(array);
            watcher1.Stop();
        }

        static void Test3()
        {
            var watcher1 = new Stopwatch();
            var setting = LoadSetting();
            var helper = new XmlHelper(setting);
            watcher1.Start();
            var array = helper.ReadToArray();
            Console.WriteLine("Array: Read: {0}", watcher1.ElapsedMilliseconds);
            watcher1.Stop();
        }

        private static XmlSetting LoadSetting()
        {
            var json = File.ReadAllText("Param.json");
            return JsonConvert.DeserializeObject<XmlSetting>(json);
        }

        static void WriteCsv(XmlItem[] items)
        {
            var sb = new StringBuilder();
            //for (int i = 0; i < items.Count(); i++)
            for (int i = 0; i < 100; i++)
            {
                sb.AppendFormat("{0},{1} \r\n", items[i].Id, items[i].Value);
            }
            File.WriteAllText("output.csv", sb.ToString());
        }

        private static void Generate()
        {
            var watcher = new Stopwatch();
            var setting = LoadSetting();
            var helper = new XmlHelper(setting);
            watcher.Start();
            Console.WriteLine("Generating...");
            helper.Generate();
            Console.WriteLine("Generated completed: {0}", watcher.Elapsed);
        }
    }
}
